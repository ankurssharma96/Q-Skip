package com.example.cartapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.cartapp.beans.Product;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int RC_BARCODE_CAPTURE = 9001;
    private static final String TAG = "BarcodeMain";
    FirebaseDatabase database;
    DatabaseReference myRef;

    final ArrayList<Product> productArrayList = new ArrayList<>();

    private Button cart_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cart_button = findViewById(R.id.read_barcode);
        findViewById(R.id.read_barcode).setOnClickListener(this);

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Inventory");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot: dataSnapshot.getChildren())
                {
                    Product p = postSnapshot.getValue(Product.class);
                    productArrayList.add(p);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("The read failed: " ,databaseError.getMessage());

            }
        });



    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.read_barcode) {
            //            launch barcode activity.
            Intent intent = new Intent(this, BarcodeCaptureActivity.class);
            intent.putExtra(BarcodeCaptureActivity.AutoFocus, true);
            intent.putExtra(BarcodeCaptureActivity.AutoCapture, true);
            startActivityForResult(intent, RC_BARCODE_CAPTURE);
        }
    }


    /**
     * Called when an activity you launched exits, giving you the requestCode
     * you started it with, the resultCode it returned, and any additional
     * data from it.  The <var>resultCode</var> will be
     * {@link #RESULT_CANCELED} if the activity explicitly returned that,
     * didn't return any result, or crashed during its operation.
     * <p/>
     * <p>You will receive this call immediately before onResume() when your
     * activity is re-starting.
     * <p/>
     *
     * @param requestCode The integer request code originally supplied to
     *                    startActivityForResult(), allowing you to identify who this
     *                    result came from.
     * @param resultCode  The integer result code returned by the child activity
     *                    through its setResult().
     * @param data        An Intent, which can return result data to the caller
     *                    (various data can be attached to Intent "extras").
     * @see #startActivityForResult
     * @see #createPendingResult
     * @see #setResult(int)
     */

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RC_BARCODE_CAPTURE) {
            if (resultCode == CommonStatusCodes.SUCCESS) {
                if (data != null) {
                    Barcode barcode = data.getParcelableExtra(BarcodeCaptureActivity.BarcodeObject);

                    Log.d(TAG, "Barcode read: " + barcode.displayValue);
                    Toast.makeText(getApplicationContext(), barcode.displayValue, Toast.LENGTH_LONG).show();
                    Product p = getProduct(barcode.displayValue);
                    if (p != null)
                        addItemToCart(p);
                    else
                        Toast.makeText(getApplicationContext(),"Item not found in inventory",Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), R.string.barcode_failure, Toast.LENGTH_LONG).show();
                    Log.d(TAG, "No barcode captured, intent data is null");
                }
            } else {
                Toast.makeText(getApplicationContext(), R.string.barcode_error, Toast.LENGTH_SHORT).show();
            }
        }
        else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
    private Product getProduct(String displayValue) {
        for (Product item: productArrayList)
        {
            if (item.getId().equals(displayValue))
                return item;
        }
        return null;
    }

    private void addItemToCart(final Product p) {
        myRef = database.getReference().child("Cart");


        myRef.child(p.getId()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Product product = dataSnapshot.getValue(Product.class);
                if (product == null)
                {
                    product = new Product(p.getId(),p.getName(),p.getPrice(),p.getDescription(),"1");
                    //database.getReference().child("Cart").child(product.getId()).setValue(product);
                }
                else {
                    Integer count = Integer.parseInt(product.getQty());
                    count += 1;
                    product.setQty(count.toString());
                }
                database.getReference().child("Cart").child(product.getId()).setValue(product);
                final Integer price = Integer.parseInt(product.getPrice());

                database.getReference().child("SubTotal").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String st = (String) dataSnapshot.getValue();
                        Integer temp = price + Integer.parseInt(st);
                        database.getReference().child("SubTotal").setValue(temp.toString());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                database.getReference().child("CartSize").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String st = (String) dataSnapshot.getValue();
                        Integer temp = 1 + Integer.parseInt(st);
                        database.getReference().child("CartSize").setValue(temp.toString());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
