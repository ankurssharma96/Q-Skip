package com.example.mobileapp;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.mobileapp.beans.Product;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>{

    private ArrayList<Product> dataList;

    public MyAdapter(ArrayList<Product> dataList)
    {
        this.dataList=dataList;
    }

    @NonNull
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View listItem = layoutInflater.inflate(R.layout.list_item,viewGroup,false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder viewHolder, int i) {
        final Product product = dataList.get(i);
        viewHolder.name_text_view.setText(product.getName());
        viewHolder.description_text_view.setText(product.getDescription());
        viewHolder.price_text_view.setText("₹" + product.getPrice() );
        viewHolder.quantity_text_view.setText(product.getQty());


    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView name_text_view;
        public TextView description_text_view;
        public TextView price_text_view;
        public TextView quantity_text_view;
        public RelativeLayout relativeLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            this.name_text_view = itemView.findViewById(R.id.product_name);
            this.description_text_view = itemView.findViewById(R.id.product_description);
            this.price_text_view = itemView.findViewById(R.id.product_price);
            this.quantity_text_view = itemView.findViewById(R.id.product_quantity);
            this.relativeLayout = itemView.findViewById(R.id.constraint_layout);

        }
    }
}
