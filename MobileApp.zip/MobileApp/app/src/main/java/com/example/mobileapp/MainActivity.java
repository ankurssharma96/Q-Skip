package com.example.mobileapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button in;
    Button out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        in = findViewById(R.id.in_store);
        out = findViewById(R.id.out_store);
        in.setText(getString(R.string.link_trolley));
        out.setText(getString(R.string.find_walmart));
        in.setOnClickListener(this);
        out.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.in_store)
        {
            Intent intent =new Intent(this,CartActivity.class);
            startActivity(intent);
        }
        else if (v.getId() == R.id.out_store)
        {
            Intent intent = new Intent(this,LocationSuggestion.class);
            startActivity(intent);
        }
    }
}
